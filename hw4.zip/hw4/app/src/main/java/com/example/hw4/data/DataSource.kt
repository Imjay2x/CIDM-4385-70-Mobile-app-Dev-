package com.example.hw4.data

import com.example.hw4.Clickbait
import com.example.hw4.R

object DataSource {
    val Articles = listOf(
        Clickbait(R.string.travel, R.drawable.travel),
        Planet(R.string.venus, R.drawable.venus),
        Planet(R.string.earth, R.drawable.earth),
        Planet(R.string.mars, R.drawable.mars),
        Planet(R.string.ceres, R.drawable.ceres),
        Planet(R.string.jupiter, R.drawable.jupiter),
        Planet(R.string.saturn, R.drawable.saturn),
        Planet(R.string.uranus, R.drawable.uranus),
        Planet(R.string.neptune, R.drawable.neptune),
        Planet(R.string.pluto, R.drawable.pluto)
    )
}