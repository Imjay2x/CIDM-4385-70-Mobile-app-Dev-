package com.example.clickbaitapp.ui.theme

data class CardItem(
    val imageResId: Int,
    val title: String,
    val description: String
)
