package com.example.clickbaitapp.ui.theme

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.clickbaitapp.R // Replace with your package name
import androidx.core.view.ViewCompat
import androidx.core.view.marginStart
import androidx.core.view.marginEnd

class CardAdapter(private val cardItems: List<CardItem>) :
    RecyclerView.Adapter<CardAdapter.CardViewHolder>() {

    class CardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardImage: ImageView = itemView.findViewById(ViewCompat.generateViewId())
        val cardTitle: TextView = itemView.findViewById(ViewCompat.generateViewId())
        val cardDescription: TextView = itemView.findViewById(ViewCompat.generateViewId())
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        // Create CardView
        val cardView = CardView(parent.context).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(
                    dpToPx(8, parent.context),
                    dpToPx(8, parent.context),
                    dpToPx(8, parent.context),
                    dpToPx(8, parent.context),
                )
            }
            radius = dpToPx(8, parent.context).toFloat() // set corner radius
            cardElevation = dpToPx(4, parent.context).toFloat() // set elevation
        }

        // Create LinearLayout for inner layout
        val linearLayout = LinearLayout(parent.context).apply {
            id = ViewCompat.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            setPadding(
                dpToPx(16, parent.context),
                dpToPx(16, parent.context),
                dpToPx(16, parent.context),
                dpToPx(16, parent.context)
            )

        }


        // Create ImageView
        val cardImage = ImageView(parent.context).apply {
            id = ViewCompat.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(150, parent.context)
            )

            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.ic_launcher_background)
        }
        linearLayout.addView(cardImage)

        // Create Title TextView
        val cardTitle = TextView(parent.context).apply {
            id = ViewCompat.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(8, parent.context)
            }

            textSize = 18f
            var textStyle = Typeface.BOLD
            text = "Clickbait Title Here"

        }
        linearLayout.addView(cardTitle)


        // Create Description TextView
        val cardDescription = TextView(parent.context).apply {
            id = ViewCompat.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(4, parent.context)
                class CardAdapter : RecyclerView.Adapter<CardAdapter.CardViewHolder>() {

                    // ... other code ...

                    inner class CardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
                        val titleTextView: TextView =
                            itemView.findViewById(R.id.titleTextView) // Line 21
                        // ... other views ...
                    }

                    // ... other code ...

                    override fun onCreateViewHolder(
                        parent: ViewGroup,
                        viewType: Int
                    ): CardViewHolder {
                        val view = LayoutInflater.from(parent.context)
                            .inflate(R.layout.card_item, parent, false)
                        return CardViewHolder(view) // Line 111
                    }

                    override fun getItemCount(): Int {
                        TODO("Not yet implemented")
                    }

                    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
                        TODO("Not yet implemented")
                    }

                    // ... other code ...
                }
            }

            textSize = 14f
            text = "A shocking story awaits you..."
        }

        linearLayout.addView(cardDescription)

        // Add the linear layout to the cardview
        cardView.addView(linearLayout)
        return CardViewHolder(cardView)
    }
    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        val cardItem = cardItems[position]
        holder.cardImage.setImageResource(cardItem.imageResId)
        holder.cardTitle.text = cardItem.title
        holder.cardDescription.text = cardItem.description

        holder.itemView.setOnClickListener {
        }
    }

    override fun getItemCount() = cardItems.size
    //Helper to handle dp to px conversions
    private fun dpToPx(dp: Int, context: Context): Int {
        val scale = context.resources.displayMetrics.density
        return (dp * scale + 0.5f).toInt()
    }
}