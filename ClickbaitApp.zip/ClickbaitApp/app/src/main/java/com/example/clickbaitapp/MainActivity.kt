package com.example.clickbaitapp

import android.os.Bundle
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import com.example.clickbaitapp.R
import com.example.clickbaitapp.ui.theme.CardAdapter
import com.example.clickbaitapp.ui.theme.CardItem

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Create the root constraint layout
        val rootLayout = ConstraintLayout(this).apply {
            id = ConstraintLayout.generateViewId()
            layoutParams = ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        recyclerView = RecyclerView(this).apply {
            id = RecyclerView.generateViewId()
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        // Add recyclerView to the root layout
        rootLayout.addView(recyclerView)

        // Apply layout constraints to the recycler view to fill the screen
        val constraintSet = ConstraintSet()
        constraintSet.apply {
            connect(recyclerView.id, ConstraintSet.TOP, rootLayout.id, ConstraintSet.TOP)
            connect(recyclerView.id, ConstraintSet.BOTTOM, rootLayout.id, ConstraintSet.BOTTOM)
            connect(recyclerView.id, ConstraintSet.START, rootLayout.id, ConstraintSet.START)
            connect(recyclerView.id, ConstraintSet.END, rootLayout.id, ConstraintSet.END)
        }.applyTo(rootLayout)

        // Set the content view to our new root layout
        setContentView(rootLayout)

        // Setup data and adapter
        val cardItems = listOf(
            CardItem(R.drawable.ic_launcher_background, "Shocking Truth About Cats!", "They're not as innocent as you think..."),
            CardItem(R.drawable.ic_launcher_background, "You Won't Believe What Happened!", "This will change your perspective on life."),
            CardItem(R.drawable.ic_launcher_background, "Doctors Hate Him!", "Find out how he lost 50 pounds in 2 weeks with a secret trick"),
            CardItem(R.drawable.ic_launcher_background, "This One Weird Trick...", "Make big money in your free time"),
            CardItem(R.drawable.ic_launcher_background, "Her Response Left Me Speechless", "A must see for yourself"),
            CardItem(R.drawable.ic_launcher_background, "Top 10 Most Amazing Things In Life", "Life is more amazing than we think"),
            CardItem(R.drawable.ic_launcher_background, "My Life Changed After This", "Things never be the same again"),
            CardItem(R.drawable.ic_launcher_background, "The Most Epic Battle Ever", "You'll be shocked what happen next"),

            )
        val cardAdapter = CardAdapter(cardItems)
        recyclerView.adapter = cardAdapter
    }
}