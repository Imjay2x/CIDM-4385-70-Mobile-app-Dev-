package com.example.reminderapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

data class Reminder(val day: String, val text: String, val imageRes: Int)

@Composable
fun ReminderApp() {
    val reminders = listOf(
        Reminder("Monday", "Take your medication today.", R.drawable.medication),
        Reminder("Tuesday", "Exercise today. Go outside and go for a run or practice yoga.", R.drawable.exercise),
        Reminder("Wednesday", "Study for class and finish your homework.", R.drawable.work),
        Reminder("Thursday", "Meditate at least 5 minutes today.", R.drawable.meditate),
        Reminder("Friday", "Stay caught up at work.", R.drawable.work),
        Reminder("Saturday", "Sleep 8 hours tonight to re-energize.", R.drawable.sleep),
        Reminder("Sunday", "Carve out some time to spend with friends.", R.drawable.friends),
        Reminder("Congratulations", "Enjoy time for yourself!", R.drawable.party),
    )

    LazyColumn {
        items(reminders) { reminder ->
            ReminderCard(reminder)
        }
    }
}

@Composable
fun ReminderCard(reminder: Reminder) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = 4.dp
    ) {
        Column {
            Image(
                painter = painterResource(id = reminder.imageRes),
                contentDescription = "Reminder Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(194.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = reminder.day,
                modifier = Modifier.padding(16.dp)
            )
            Text(
                text = reminder.text,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewReminderApp() {
    ReminderApp()
}
